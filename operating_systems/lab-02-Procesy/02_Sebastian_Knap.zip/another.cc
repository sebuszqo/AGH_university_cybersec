#include <stdio.h>
#include <stdlib.h>

int main(){
	printf("Hello, I'm another program!\n");
	getchar();
	return 0;
}
